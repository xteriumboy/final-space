<?php
/**
 * store_protected_inc/sealed_loader.php — include_sealed() for STORE
 * Locates encrypted PHP source, decrypts via AES secret, caches to data/cache/, then includes.
 *
 * Usage: include_sealed('inc/boot.php');
 */
declare(strict_types=1);

if (!defined('FS_INC_DIR')) define('FS_INC_DIR', __DIR__);
if (!defined('FS_ROOT')) define('FS_ROOT', realpath(FS_INC_DIR . '/..') ?: dirname(FS_INC_DIR));
if (!defined('FS_SITE_ROOT')) define('FS_SITE_ROOT', dirname(FS_ROOT));

require_once FS_INC_DIR . '/aes_helper.php';
require_once FS_INC_DIR . '/security.php';

function include_sealed(string $relPath): void {
    $rel = ltrim($relPath, '/');
    // Prefer files under /protected/
    $candidatePlain = FS_SITE_ROOT . '/' . $rel;
    $candidateProt  = FS_ROOT . '/' . $rel; // e.g., /protected/inc/boot.php

    // Candidate encrypted variants
    $candidates = [
        $candidateProt . '.aes',
        $candidateProt . '.sealed',
        $candidateProt . '.enc',
        $candidatePlain . '.aes',
        $candidatePlain . '.sealed',
        $candidatePlain . '.enc',
        $candidateProt, // fallback plaintext
        $candidatePlain // fallback plaintext
    ];

    $src = null;
    foreach ($candidates as $c) {
        if (is_file($c)) { $src = $c; break; }
    }
    if ($src === null) {
        http_response_code(500);
        die("<pre style='color:#ff9b9b'>[FS] include_sealed: source not found for " . htmlspecialchars($relPath) . "</pre>");
    }

    $key = fs_get_aes_key();
    $code = '';
    if (preg_match('/\.(aes|sealed|enc)$/i', $src)) {
        if (!$key) {
            http_response_code(500);
            die("<pre style='color:#ff9b9b'>[FS-AES] Missing AES secret at: " . htmlspecialchars(FS_KEYS_DIR . '/aes_secret.key') . "</pre>");
        }
        $blob = (string)@file_get_contents($src);
        try {
            $code = fs_decrypt_blob($blob, $key);
        } catch (Throwable $e) {
            http_response_code(500);
            die("<pre style='color:#ff9b9b'>[FS-AES] Decrypt failed: " . htmlspecialchars($e->getMessage()) . "</pre>");
        }
    } else {
        $code = (string)@file_get_contents($src);
    }

    // Cache to /protected/data/cache/<hash>.php then include
    $cacheDir = FS_ROOT . '/data/cache';
    if (!is_dir($cacheDir)) @mkdir($cacheDir, 0755, true);
    $hash = sha1($src . '|' . strlen($code));
    $cacheFile = $cacheDir . '/' . $hash . '.php';
    if (!is_file($cacheFile)) {
        @file_put_contents($cacheFile, "<?php\n" . $code);
    }
    require $cacheFile;
}
