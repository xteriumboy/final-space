<?php
/**
 * store_protected_inc/boot.php — path-safe bootstrap for STORE
 * Defines FS_ROOT (/protected), FS_KEYS_DIR, FS_DATA_DIR and loads helpers.
 */
declare(strict_types=1);

if (!defined('FS_INC_DIR')) {
    define('FS_INC_DIR', __DIR__);
}
if (!defined('FS_ROOT')) {
    define('FS_ROOT', realpath(FS_INC_DIR . '/..') ?: dirname(FS_INC_DIR)); // /protected
}
if (!defined('FS_SITE_ROOT')) {
    define('FS_SITE_ROOT', dirname(FS_ROOT));
}
if (!defined('FS_KEYS_DIR')) {
    define('FS_KEYS_DIR', FS_ROOT . '/keys');
}
if (!defined('FS_DATA_DIR')) {
    define('FS_DATA_DIR', FS_ROOT . '/data');
}
if (!is_dir(FS_DATA_DIR)) @mkdir(FS_DATA_DIR, 0755, true);
if (!is_dir(FS_DATA_DIR . '/cache')) @mkdir(FS_DATA_DIR . '/cache', 0755, true);

require_once FS_INC_DIR . '/security.php';
require_once FS_INC_DIR . '/aes_helper.php';
require_once FS_INC_DIR . '/manifest_verify.php';
require_once FS_INC_DIR . '/sealed_loader.php';

define('FS_AES_SECRET_FILE', FS_KEYS_DIR . '/aes_secret.key');
