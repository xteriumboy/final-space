<?php
/**
 * store_protected_inc/aes_helper.php — AES helpers for STORE
 * Supports headered formats FS-AES|v1| and JSON {"alg","iv","tag","ct"} for GCM/CBC.
 */
declare(strict_types=1);

function fs_get_aes_key(): ?string {
    // Path defined by boot.php as FS_KEYS_DIR
    $file = (defined('FS_KEYS_DIR') ? FS_KEYS_DIR : (__DIR__ . '/../keys')) . '/aes_secret.key';
    if (is_file($file)) {
        $key = trim((string)@file_get_contents($file));
        if ($key !== '') return $key;
    }
    return null;
}

/**
 * Decrypts a sealed blob (string) with the AES key.
 * Tries the following formats in order:
 * 1) "FS-AES|v1|ALG|...\nBASE64_CIPHERTEXT"
 * 2) JSON: {"alg":"AES-256-GCM","iv":"...","tag":"...","ct":"..."}
 * 3) Raw base64 ciphertext with IV prepended (CBC), env var FS_AES_IVLEN=16
 */
function fs_decrypt_blob(string $blob, string $key): string {
    $blob = ltrim($blob);
    // Format 1: FS-AES|v1|...
    if (str_starts_with($blob, 'FS-AES|v1|')) {
        $parts = explode("\n", $blob, 2);
        $header = $parts[0];
        $payloadB64 = $parts[1] ?? '';
        $h = explode('|', $header);
        // e.g., FS-AES|v1|AES-256-CBC|iv=...|hmac=... or AES-256-GCM|iv=...|tag=...
        $alg = $h[2] ?? 'AES-256-CBC';
        $meta = [];
        for ($i=3; $i<count($h); $i++) {
            if (strpos($h[$i], '=') !== false) {
                [$k,$v] = explode('=', $h[$i], 2);
                $meta[$k] = $v;
            }
        }
        $ct = base64_decode($payloadB64, true);
        if ($ct === false) throw new RuntimeException('Invalid base64 ciphertext');
        $iv = isset($meta['iv']) ? base64_decode($meta['iv'], true) : null;
        $tag = isset($meta['tag']) ? base64_decode($meta['tag'], true) : null;

        if ($alg === 'AES-256-GCM') {
            $plain = @openssl_decrypt($ct, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv ?? '', $tag ?? '');
        } else {
            // default to CBC
            $plain = @openssl_decrypt($ct, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv ?? '');
        }
        if ($plain === false) throw new RuntimeException('openssl_decrypt failed for ' . $alg);
        return $plain;
    }

    // Format 2: JSON
    if ($blob[0] === '{') {
        $j = json_decode($blob, true);
        if (is_array($j) && isset($j['alg'], $j['iv'], $j['ct'])) {
            $alg = (string)$j['alg'];
            $iv  = base64_decode((string)$j['iv'], true) ?: '';
            $ct  = base64_decode((string)$j['ct'], true);
            $tag = isset($j['tag']) ? base64_decode((string)$j['tag'], true) : null;
            if ($ct === false) throw new RuntimeException('Invalid base64 ct in JSON');
            if ($alg === 'AES-256-GCM') {
                $plain = @openssl_decrypt($ct, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag ?? '');
            } else {
                $plain = @openssl_decrypt($ct, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
            }
            if ($plain === false) throw new RuntimeException('openssl_decrypt failed JSON ' . $alg);
            return $plain;
        }
    }

    // Format 3: raw base64 with IV prefix (CBC)
    $raw = base64_decode($blob, true);
    if ($raw !== false) {
        $ivlen = 16; // AES block size
        $iv = substr($raw, 0, $ivlen);
        $ct = substr($raw, $ivlen);
        $plain = @openssl_decrypt($ct, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
        if ($plain !== false) return $plain;
    }

    throw new RuntimeException('Unsupported sealed blob format');
}
