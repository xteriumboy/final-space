<?php require_once __DIR__.'/../inc/license_core.php'; require_once __DIR__.'/guard.php';
$uploads=realpath(__DIR__.'/../uploads'); if(!$uploads) @mkdir(__DIR__.'/../uploads',0775,true); $uploads=realpath(__DIR__.'/../uploads');
$msg=''; if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['delete'])){ $rel=$_POST['delete']; $abs=realpath(__DIR__.'/..'.$rel); if($abs && strpos($abs,$uploads)===0 && is_file($abs)){ @unlink($abs); $msg='Deleted: '.$rel; } else { $msg='Invalid path'; } }
$files=[]; if($uploads){ $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($uploads, FilesystemIterator::SKIP_DOTS)); foreach($it as $f){ if(is_file($f)){ $rel=str_replace(realpath(__DIR__.'/..'),'',$f->getPathname()); $files[]=$rel; } } }
?><!doctype html><meta charset="utf-8"><style>body{background:#0b0f14;color:#e7ebf0;font-family:system-ui;padding:16px} table{width:100%;border-collapse:collapse} th,td{border:1px solid #1f2937;padding:8px} button{background:#2563eb;border:0;color:#fff;border-radius:8px;padding:8px 12px;cursor:pointer} a{color:#8ab4ff}</style>
<h1>File Manager</h1><nav><a href="/admin/products.php">Products</a></nav>
<?php if($msg) echo '<div style="color:#9ef">'.$msg.'</div>'; ?>
<table><tr><th>Path</th><th>Size</th><th>Action</th></tr>
<?php foreach($files as $rel){ $abs=realpath(__DIR__.'/..'.$rel); echo '<tr><td>'.htmlspecialchars($rel).'</td><td>'.(is_file($abs)?filesize($abs):0).'</td><td><form method="post" onsubmit="return confirm(\'Delete?\')"><input type="hidden" name="delete" value="'.htmlspecialchars($rel).'"><button>Delete</button></form></td></tr>'; } ?>
</table>
