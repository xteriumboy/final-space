<?php
/**
 * Final Space Store — admin/file_manager.php v1.0
 * --------------------------------------------------
 * - Requires admin session (fs_admin)
 * - Upload product images (jpg/png/webp)
 * - Upload product archives (zip/rar)
 * - Saves files into /uploads/
 * - Lists all uploaded files with delete buttons
 * - Logs everything to /data/file_manager_debug.txt
 * - Works with PHP 8.2 on shared hosting
 */

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);

$CFG = require __DIR__ . '/../config.php';
$debug = isset($_GET['fsdebug']) || !empty($CFG['debug']);
$logFile = __DIR__ . '/../data/file_manager_debug.txt';
@mkdir(dirname($logFile), 0755, true);

function log_debug($msg, $ctx = []) {
    global $logFile;
    $entry = '[' . date('Y-m-d H:i:s') . '] ' . $msg;
    if ($ctx) $entry .= ' | ' . json_encode($ctx, JSON_UNESCAPED_SLASHES);
    $entry .= PHP_EOL;
    @file_put_contents($logFile, $entry, FILE_APPEND);
}

/* ---------- Protect ---------- */
if (empty($_SESSION['fs_admin'])) {
    header('Location: login.php');
    exit;
}

/* ---------- Upload handling ---------- */
$uploadDir = __DIR__ . '/../uploads';
@mkdir($uploadDir, 0755, true);
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $name = basename($file['name']);
    $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $allowed = ['jpg','jpeg','png','webp','zip','rar'];

    if (!in_array($ext, $allowed)) {
        $msg = "❌ Invalid file type ($ext)";
        log_debug('invalid_ext', ['name'=>$name]);
    } elseif ($file['size'] > 100*1024*1024) {
        $msg = '❌ File too large (max 100 MB)';
        log_debug('file_too_large', ['name'=>$name,'size'=>$file['size']]);
    } else {
        $target = $uploadDir . '/' . preg_replace('/[^a-zA-Z0-9._-]/','_',$name);
        if (move_uploaded_file($file['tmp_name'], $target)) {
            $msg = "✅ Uploaded: $name";
            log_debug('upload_ok', ['name'=>$name,'size'=>$file['size']]);
        } else {
            $msg = '❌ Upload failed (permissions?)';
            log_debug('upload_fail', ['name'=>$name]);
        }
    }
}

/* ---------- File deletion ---------- */
if (isset($_GET['delete'])) {
    $del = basename($_GET['delete']);
    $path = $uploadDir . '/' . $del;
    if (is_file($path)) {
        unlink($path);
        $msg = "🗑️ Deleted: $del";
        log_debug('file_deleted', ['file'=>$del]);
    }
}

/* ---------- File list ---------- */
$files = array_values(array_filter(scandir($uploadDir), fn($f)=>!in_array($f,['.','..'])));
sort($files);

/* ---------- HTML ---------- */
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>File Manager - Final Space Admin</title>
<style>
body{font-family:Inter,Segoe UI,Arial;background:#0f172a;color:#e2e8f0;margin:0}
header{background:#1e293b;padding:20px 40px;display:flex;justify-content:space-between;align-items:center}
h1{margin:0;font-size:22px;color:#93c5fd}
a{color:#93c5fd;text-decoration:none}
main{padding:40px;max-width:1000px;margin:auto}
form{margin-bottom:25px;background:#1e293b;padding:20px;border-radius:12px}
input[type=file]{padding:10px;border:none;background:#334155;color:#fff;border-radius:8px;width:70%}
button{background:#2563eb;color:#fff;border:none;padding:10px 20px;border-radius:8px;cursor:pointer}
button:hover{background:#1d4ed8}
.msg{margin-top:10px;color:#a5b4fc;font-weight:500}
table{width:100%;border-collapse:collapse;margin-top:20px}
th,td{padding:10px;border-bottom:1px solid #334155;text-align:left}
th{background:#334155}
tr:hover{background:#2d3d57}
.debug{margin-top:25px;background:#0b1220;color:#38bdf8;padding:15px;border-radius:8px;font-family:ui-monospace;font-size:13px}
</style>
</head>
<body>
<header>
  <h1>File Manager</h1>
  <div>
    <a href="index.php">← Back to Dashboard</a> |
    <a href="logout.php" style="color:#f87171">Logout</a>
  </div>
</header>
<main>
  <h2>Upload New File</h2>
  <form method="post" enctype="multipart/form-data">
    <input type="file" name="file" required>
    <button type="submit">Upload</button>
    <?php if($msg): ?><div class="msg"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
  </form>

  <h2>Uploaded Files</h2>
  <?php if(!$files): ?>
    <p>No files uploaded yet.</p>
  <?php else: ?>
  <table>
    <tr><th>File</th><th>Size (KB)</th><th>Actions</th></tr>
    <?php foreach($files as $f):
        $size = round(filesize($uploadDir.'/'.$f)/1024,1);
    ?>
      <tr>
        <td><?php echo htmlspecialchars($f); ?></td>
        <td><?php echo $size; ?></td>
        <td><a href="?delete=<?php echo urlencode($f); ?>" onclick="return confirm('Delete this file?')">Delete</a></td>
      </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>

  <?php if($debug): ?>
  <div class="debug">
    DEBUG MODE — remove later<br>
    Upload dir: <?php echo htmlspecialchars($uploadDir); ?><br>
    Files count: <?php echo count($files); ?><br>
    Last msg: <?php echo htmlspecialchars($msg); ?><br>
  </div>
  <?php endif; ?>
</main>
</body>
</html>
