<?php require_once __DIR__.'/../inc/license_core.php'; require_once __DIR__.'/guard.php'; $cfg=require __DIR__.'/../config.php';
try{$pdo=new PDO($cfg['db']['dsn'],$cfg['db']['user'],$cfg['db']['pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);}catch(Throwable $e){die('DB error');}
if($_SERVER['REQUEST_METHOD']==='POST'){ $name=trim($_POST['name']??''); $price=floatval($_POST['price']??0); $desc=trim($_POST['description']??''); $image=null; if(!empty($_FILES['image']['tmp_name'])){ $dir=__DIR__.'/../uploads/image/'; if(!is_dir($dir)) mkdir($dir,0775,true); $ext=pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION)?:'jpg'; $fn=uniqid('img_').'.'.$ext; move_uploaded_file($_FILES['image']['tmp_name'],$dir.'/'.$fn); $image='/uploads/image/'.$fn; } $file_path=null; if(!empty($_FILES['file']['tmp_name'])){ $dir=__DIR__.'/../uploads/download/'; if(!is_dir($dir)) mkdir($dir,0775,true); $ext=pathinfo($_FILES['file']['name'],PATHINFO_EXTENSION)?:'bin'; $fn=uniqid('file_').'.'.$ext; move_uploaded_file($_FILES['file']['tmp_name'],$dir.'/'.$fn); $file_path='/uploads/download/'.$fn; } $st=$pdo->prepare('INSERT INTO products(name,description,price,image,file_path) VALUES(?,?,?,?,?)'); $st->execute([$name,$desc,$price,$image,$file_path]); header('Location: /admin/products.php'); exit; }
$rows=$pdo->query('SELECT * FROM products ORDER BY id DESC')->fetchAll(PDO::FETCH_ASSOC);
?><!doctype html><meta charset="utf-8"><style>body{background:#0b0f14;color:#e7ebf0;font-family:system-ui;padding:16px} input,textarea{background:#0f172a;border:1px solid #1f2937;color:#e7ebf0;border-radius:8px;padding:8px;width:100%;box-sizing:border-box;margin:6px 0} table{width:100%;border-collapse:collapse;margin-top:12px} th,td{border:1px solid #1f2937;padding:8px} button{background:#2563eb;border:0;color:#fff;border-radius:8px;padding:8px 12px;cursor:pointer}</style>
<h1>Products</h1><nav><a href="/admin/files.php" style="color:#8ab4ff">File Manager</a></nav>
<form method="post" enctype="multipart/form-data">
  <input name="name" placeholder="Name" required>
  <input name="price" type="number" step="0.01" placeholder="Price" required>
  <textarea name="description" placeholder="Description"></textarea>
  <label>Image <input type="file" name="image" accept="image/*"></label>
  <label>File <input type="file" name="file"></label>
  <button>Create</button>
</form>
<hr>
<table><tr><th>ID</th><th>Image</th><th>Name</th><th>Price</th><th>File</th><th>Actions</th></tr>
<?php foreach($rows as $r){ echo '<tr><td>'.$r['id'].'</td><td>'.($r['image']?'<img src="'.$r['image'].'" style="height:40px">':'').'</td><td>'.$r['name'].'</td><td>'.$r['price'].'</td><td>'.htmlspecialchars($r['file_path']).'</td><td><a href="/admin/edit.php?id='.$r['id'].'">Edit</a></td></tr>'; } ?>
</table>
