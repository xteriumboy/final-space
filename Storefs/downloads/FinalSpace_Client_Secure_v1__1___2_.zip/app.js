async function checkLicense(){
  const lic = localStorage.getItem('fs_license') || '';
  const status = document.getElementById('status');
  const buttons = document.querySelectorAll('.buy-btn');
  if (!lic){ status.textContent='🔒 Locked — enter license to activate'; buttons.forEach(b=>b.disabled=true); return; }
  try{
    const res = await fetch('verify_license.php?license='+encodeURIComponent(lic));
    const data = await res.json();
    if (data.ok){
      status.textContent='✅ Activated for this domain';
      buttons.forEach(b=>{
        b.disabled=false;
        b.addEventListener('click', ()=>{
          const file=b.dataset.file;
          location.href='secure_download.php?license='+encodeURIComponent(lic)+'&file='+encodeURIComponent(file);
        }, { once:true });
      });
    }else{
      status.textContent='❌ Invalid license — try again'; buttons.forEach(b=>b.disabled=true);
    }
  }catch(e){ status.textContent='⚠️ License server unreachable'; }
}
function saveLicense(){ const v=document.getElementById('licenseInput').value.trim(); if(!v)return alert('Enter license'); localStorage.setItem('fs_license',v); location.reload(); }
document.addEventListener('DOMContentLoaded', checkLicense);
