<?php
return [
  'license_server' => 'https://licenses.final-space.com/api/verify_license.php',
  'public_key'     => 'https://licenses.final-space.com/api/public_key.php',
  'site_domain'    => $_SERVER['SERVER_NAME'],
  'product_list'   => [
    ['id'=>1,'name'=>'Pro Suite','price'=>'0.10','file'=>'product1.rar'],
    ['id'=>2,'name'=>'Developer Pack','price'=>'0.15','file'=>'product2.rar'],
    ['id'=>3,'name'=>'Asset Bundle X','price'=>'0.20','file'=>'product3.rar']
  ]
];
?>
