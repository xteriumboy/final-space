Final Space Client — Secure License Store
----------------------------------------
Upload to your client site root (e.g., 2.final-space.com).

- Put real product files into /private_files matching names in config.php.
- Update license_server URL in config.php if needed.
- Open site, paste your license, click Activate.
- Buttons unlock only if license verifies from server.
- secure_download.php re-verifies server-side before streaming.
