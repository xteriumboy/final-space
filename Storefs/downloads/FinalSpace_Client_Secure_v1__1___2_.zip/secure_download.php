<?php
$config = require __DIR__ . '/config.php';
$license = $_GET['license'] ?? '';
$file = basename($_GET['file'] ?? '');
if (!$license || !$file) { http_response_code(400); echo 'Missing parameters'; exit; }
$verifyUrl = $config['license_server'] . '?license=' . urlencode($license) . '&domain=' . urlencode($_SERVER['SERVER_NAME']);
$verify = @file_get_contents($verifyUrl);
$data = $verify ? json_decode($verify, true) : null;
if (!$data || empty($data['ok'])) { http_response_code(403); echo 'License invalid.'; exit; }
if (!empty($data['bound_domain']) && stripos($_SERVER['SERVER_NAME'], $data['bound_domain']) === false) {
  http_response_code(403); echo 'License not bound to this domain.'; exit;
}
$path = __DIR__ . '/private_files/' . $file;
if (!is_file($path)) { http_response_code(404); echo 'File not found'; exit; }
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($path) . '"');
header('Content-Length: ' . filesize($path));
readfile($path); exit;
?>
