<?php
header('Content-Type: application/json');
$config = require __DIR__ . '/config.php';
$license = $_GET['license'] ?? '';
$domain  = $config['site_domain'] ?? $_SERVER['SERVER_NAME'];
if (!$license) { echo json_encode(['ok'=>false,'error'=>'missing_license']); exit; }
$url = $config['license_server'] . '?license=' . urlencode($license) . '&domain=' . urlencode($domain);
$resp = @file_get_contents($url);
if ($resp === false) { echo json_encode(['ok'=>false,'error'=>'server_unreachable']); exit; }
echo $resp;
?>
